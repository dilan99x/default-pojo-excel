package com.dbs.plugin;

public class RecordField {
    private final String name;
    private final int start; // 1-based index
    private final int end;

    public RecordField(String name, int start, int end) {
        this.name = name;
        this.start = start;
        this.end = end;
    }

    public String getName() {
        return name;
    }

    public int getStart() {
        return start;
    }

    public int getEnd() {
        return end;
    }

    public String extractValue(String line) {
        if (start > end || start < 1 || end < 1 || line == null || line.isEmpty()) {
            return "";
        }

        int from = Math.max(0, start - 1);
        int to = Math.min(line.length(), end);

        if (from >= to) return "";

        return line.substring(from, to).trim();
    }
}

