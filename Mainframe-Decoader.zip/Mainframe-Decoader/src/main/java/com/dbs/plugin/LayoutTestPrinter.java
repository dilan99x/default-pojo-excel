package com.dbs.plugin;

import java.util.List;

public class LayoutTestPrinter {

    public static void main(String[] args) throws Exception {
        String layoutFilePath = "/Users/dilananushka/Documents/Batch/DQBTBMS.txt";
        String layoutNumber = "3";

        LayoutParseResult result = LayoutDefinitionParser.parse(layoutFilePath, layoutNumber);
        List<RecordField> fields = result.getFields();
        String memberName = result.getMemberName();

        System.out.println("✅ Member: " + (memberName != null ? memberName : "N/A"));
        System.out.println("Extracted Fields for Layout " + layoutNumber + ":");

        if (fields.isEmpty()) {
            System.out.println("⚠️ No fields found. Please check if layout exists in the file.");
        }

        for (RecordField field : fields) {
            System.out.printf("- %-25s | Start: %3d | End: %3d%n", field.getName(), field.getStart(), field.getEnd());
        }
    }
}