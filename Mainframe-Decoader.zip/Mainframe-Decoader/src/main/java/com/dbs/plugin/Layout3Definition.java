package com.dbs.plugin;

import java.util.ArrayList;
import java.util.List;

public class Layout3Definition {

    public static List<RecordField> getLayout3Fields() {
        List<RecordField> fields = new ArrayList<>();

        fields.add(new RecordField("BTBMS-REC-TYP", 1, 2));
        fields.add(new RecordField("BTBMS-ORIG-SYS-ID", 3, 6));
        fields.add(new RecordField("BTBMS-ORIG-SYS-KEY", 7, 26));
        fields.add(new RecordField("BTBMS-TAR-SYS-ID", 27, 30));
        fields.add(new RecordField("BTBMS-ACC-BB", 31, 34));
        fields.add(new RecordField("BTBMS-ACC-SS", 35, 40));
        fields.add(new RecordField("BTBMS-ACC-CC", 40, 35));
        fields.add(new RecordField("BTBMS-TRANS-CODE", 45, 50));
        fields.add(new RecordField("BTBMS-CR-DR-IND", 51, 51));
        fields.add(new RecordField("BTBMS-TRANS-AMT", 52, 62));
        // Add more fields if needed...

        return fields;
    }
}

