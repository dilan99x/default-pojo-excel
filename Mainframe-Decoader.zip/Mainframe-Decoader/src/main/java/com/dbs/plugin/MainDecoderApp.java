package com.dbs.plugin;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainDecoderApp {

    public static void main(String[] args) throws Exception {
        String filePath = "/Users/dilananushka/Documents/Batch/DQSP.SGNLEMI.txt"; // Update this if needed

        List<RecordField> layout3 = Layout3Definition.getLayout3Fields();
        MainframeLineDecoder decoder = new MainframeLineDecoder(layout3);

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        List<Map<String, String>> decodedRecords = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                line = line.trim();

                // Skip empty lines, trailer, header timestamp lines, or unrecognized record types
                if (line.isEmpty() || line.length() < 10 || line.startsWith("99") || !line.startsWith("01")) {
                    continue;
                }

                Map<String, String> decoded = decoder.decodeLine(line);
                decodedRecords.add(decoded);
            }
        }

        // Print final JSON array
        String finalJson = mapper.writeValueAsString(decodedRecords);
        System.out.println(finalJson);
    }
}