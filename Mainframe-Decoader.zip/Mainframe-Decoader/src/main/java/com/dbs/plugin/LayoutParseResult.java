package com.dbs.plugin;


import java.util.List;

public class LayoutParseResult {
    private final String memberName;
    private final List<RecordField> fields;

    public LayoutParseResult(String memberName, List<RecordField> fields) {
        this.memberName = memberName;
        this.fields = fields;
    }

    public String getMemberName() {
        return memberName;
    }

    public List<RecordField> getFields() {
        return fields;
    }
}

