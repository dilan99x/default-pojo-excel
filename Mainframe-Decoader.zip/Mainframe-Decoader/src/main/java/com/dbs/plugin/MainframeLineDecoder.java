package com.dbs.plugin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainframeLineDecoder {

    private final List<RecordField> layoutFields;

    public MainframeLineDecoder(List<RecordField> layoutFields) {
        this.layoutFields = layoutFields;
    }

    public Map<String, String> decodeLine(String line) {
        Map<String, String> result = new HashMap<>();

        for (RecordField field : layoutFields) {
            String value = field.extractValue(line);
            result.put(field.getName(), value);
        }

        return result;
    }
}
