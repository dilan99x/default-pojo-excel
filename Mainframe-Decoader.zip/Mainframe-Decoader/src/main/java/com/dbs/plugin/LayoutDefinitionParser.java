package com.dbs.plugin;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LayoutDefinitionParser {

    public static LayoutParseResult parse(String filePath, String layoutNumber) throws Exception {
        List<RecordField> fields = new ArrayList<>();
        String memberName = null;

        // Fix: match MEMBER line regardless of spacing
        Pattern memberPattern = Pattern.compile("MEMBER\\s+:\\s+(\\S+)", Pattern.CASE_INSENSITIVE);
        Pattern layoutStartPattern = Pattern.compile(".*START OF LAYOUT NUMBER\\s+" + layoutNumber + ".*", Pattern.CASE_INSENSITIVE);

        boolean inLayout = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                line = line.trim();

                // Extract MEMBER name once
                if (memberName == null) {
                    Matcher memberMatcher = memberPattern.matcher(line);
                    if (memberMatcher.find()) {
                        memberName = memberMatcher.group(1).trim();
                    }
                }

                // Detect layout start
                Matcher layoutMatcher = layoutStartPattern.matcher(line);
                if (layoutMatcher.find()) {
                    inLayout = true;
                    continue;
                }

                // Stop at next layout start
                if (inLayout && line.contains("START OF LAYOUT NUMBER")) {
                    break;
                }

                // Parse layout field lines
                if (inLayout && (line.startsWith("5") || line.startsWith("10"))) {
                    String[] parts = line.trim().split("\\s+");

                    if (parts.length >= 6) {
                        try {
                            int start = Integer.parseInt(parts[4]);
                            int end = Integer.parseInt(parts[5]);
                            String fieldName = parts[1];

                            if (!fieldName.equalsIgnoreCase("FILLER")) {
                                fields.add(new RecordField(fieldName, start, end));
                            }
                        } catch (NumberFormatException ignored) {
                            // Skip headers or non-field lines
                        }
                    }
                }
            }
        }

        return new LayoutParseResult(memberName, fields);
    }
}