package com.dbs.casa.plugin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcelJsonConverterApplicationTests {

	@Test
	void contextLoads() {
	}

}
