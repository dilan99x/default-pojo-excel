package com.dbs.casa.plugin.constants;

public enum TransformationSourceType {
    SUN_CBS,
    MAINFRAME,
    ALL
}
