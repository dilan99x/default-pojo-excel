package com.dbs.casa.plugin.service;

import com.dbs.casa.plugin.constants.TransformationSourceType;
import com.dbs.casa.plugin.model.ApiMapping;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

public interface JsonTransformationMediatorService {
    Map<String, ApiMapping> transformAll(MultipartFile file, TransformationSourceType type);
    byte[] generateJsonZip(MultipartFile file, TransformationSourceType type);
}
