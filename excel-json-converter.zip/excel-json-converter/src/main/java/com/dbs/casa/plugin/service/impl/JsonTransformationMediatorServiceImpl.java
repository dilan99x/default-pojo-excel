package com.dbs.casa.plugin.service.impl;

import com.dbs.casa.plugin.constants.TransformationSourceType;
import com.dbs.casa.plugin.model.ApiMapping;
import com.dbs.casa.plugin.service.*;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class JsonTransformationMediatorServiceImpl implements JsonTransformationMediatorService {
    @Autowired
    @Qualifier("sunCbsRequestJsonProducerService")
    private SunCbsRequestJsonProducerService sunCbsRequestJsonProducerService;
    @Autowired
    @Qualifier("sunCbsResponseJsonProducerService")
    private SunCbsResponseJsonProducerService sunCbsResponseJsonProducerService;
    @Autowired
    @Qualifier("mainframeRequestJsonProducerService")
    private MainframeRequestJsonProducerService mainframeRequestJsonProducerService;
    @Autowired
    @Qualifier("mainframeResponseJsonProducerService")
    private MainframeResponseJsonProducerService mainframeResponseJsonProducerService;
    @Override
    public Map<String, ApiMapping> transformAll(MultipartFile file, TransformationSourceType type) {
        Map<String, ApiMapping> resultMap = new HashMap<>();

        try {
            byte[] fileBytes = file.getBytes();
            TransformationSourceType resolvedType = (type == null) ? TransformationSourceType.ALL : type;

            switch (resolvedType) {
                case SUN_CBS -> {
                    resultMap.putAll(sunCbsRequestJsonProducerService.extractMappings(new ByteArrayInputStream(fileBytes)));
                    resultMap.putAll(sunCbsResponseJsonProducerService.extractMappings(new ByteArrayInputStream(fileBytes)));
                }

                case MAINFRAME -> {
                    resultMap.putAll(mainframeRequestJsonProducerService.extractMappings(new ByteArrayInputStream(fileBytes)));
                    resultMap.putAll(mainframeResponseJsonProducerService.extractMappings(new ByteArrayInputStream(fileBytes)));
                }

                case ALL -> {
                    resultMap.putAll(sunCbsRequestJsonProducerService.extractMappings(new ByteArrayInputStream(fileBytes)));
                    resultMap.putAll(sunCbsResponseJsonProducerService.extractMappings(new ByteArrayInputStream(fileBytes)));
                    resultMap.putAll(mainframeRequestJsonProducerService.extractMappings(new ByteArrayInputStream(fileBytes)));
                    resultMap.putAll(mainframeResponseJsonProducerService.extractMappings(new ByteArrayInputStream(fileBytes)));
                }
            }

        } catch (Exception e) {
            throw new RuntimeException(" Error reading or transforming Excel file", e);
        }

        return resultMap;
    }

    @Override
    public byte[] generateJsonZip(MultipartFile file, TransformationSourceType type) {
        try {
            Map<String, ApiMapping> mappings = transformAll(file, type);
            ObjectMapper mapper = new ObjectMapper().setSerializationInclusion(JsonInclude.Include.NON_NULL);

            ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
            try (ZipOutputStream zipOut = new ZipOutputStream(byteOut)) {
                for (Map.Entry<String, ApiMapping> entry : mappings.entrySet()) {
                    ZipEntry zipEntry = new ZipEntry(entry.getKey());
                    zipOut.putNextEntry(zipEntry);
                    byte[] jsonBytes = mapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(entry.getValue());
                    zipOut.write(jsonBytes);
                    zipOut.closeEntry();
                }

                zipOut.finish(); // finalize the ZIP properly
            }

            return byteOut.toByteArray(); //move outside the try-with-resources block

        } catch (Exception e) {
            throw new RuntimeException("Failed to generate JSON ZIP", e);
        }
    }
}
