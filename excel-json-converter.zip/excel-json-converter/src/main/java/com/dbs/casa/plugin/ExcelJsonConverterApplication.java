package com.dbs.casa.plugin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelJsonConverterApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelJsonConverterApplication.class, args);
	}

}
