package com.dbs.casa.plugin.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiField {
    private String source;
    private String sourceDataType;
    private String target;
    private String targetDataType;
    private String operationType;
    private String customData;
}
