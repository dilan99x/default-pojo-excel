package com.dbs.casa.plugin.service;

import com.dbs.casa.plugin.model.ApiMapping;

import java.io.InputStream;
import java.util.Map;

public interface JsonProducerService {
    Map<String, ApiMapping> extractMappings(InputStream inputStream) throws Exception;
}
