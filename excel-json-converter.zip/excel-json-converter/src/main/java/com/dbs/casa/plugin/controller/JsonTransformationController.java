package com.dbs.casa.plugin.controller;

import com.dbs.casa.plugin.constants.TransformationSourceType;
import com.dbs.casa.plugin.model.ApiMapping;
import com.dbs.casa.plugin.service.JsonTransformationMediatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/json-generator")
public class JsonTransformationController {

    @Autowired
    private JsonTransformationMediatorService mediatorService;

    @PostMapping(value = "/generate", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, ApiMapping>> generateJsonFromExcel(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "type", required = false) TransformationSourceType type) {
        TransformationSourceType resolvedType = (type == null) ? TransformationSourceType.ALL : type;
        Map<String, ApiMapping> result = mediatorService.transformAll(file, resolvedType);
        return ResponseEntity.ok(result);
    }
}
