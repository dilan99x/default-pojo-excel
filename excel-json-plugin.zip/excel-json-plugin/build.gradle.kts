plugins {
    id("java")
    id("org.jetbrains.intellij") version "1.17.3"
}

group = "com.dbs.plugin"
version = "3.4-RELEASE"

repositories {
    mavenCentral()
}

dependencies {
    // Apache POI for Excel reading
    implementation("org.apache.poi:poi:5.2.3")
    implementation("org.apache.poi:poi-ooxml:5.2.3")

    // Jackson for JSON writing
    implementation("com.fasterxml.jackson.core:jackson-databind:2.15.3")

    // Lombok
    compileOnly("org.projectlombok:lombok:1.18.28")
    annotationProcessor("org.projectlombok:lombok:1.18.28")
}

intellij {
    version.set("2023.2.6")
    type.set("IC")
    plugins.set(listOf())
}

tasks {
    withType<JavaCompile> {
        sourceCompatibility = "17"
        targetCompatibility = "17"
    }

    patchPluginXml {
        sinceBuild.set("232")  // Match IntelliJ IDEA 2023.2.6
        untilBuild.set("252.*")
    }

    signPlugin {
        certificateChain.set(System.getenv("CERTIFICATE_CHAIN"))
        privateKey.set(System.getenv("PRIVATE_KEY"))
        password.set(System.getenv("PRIVATE_KEY_PASSWORD"))
    }

    publishPlugin {
        token.set(System.getenv("PUBLISH_TOKEN"))
    }
}

