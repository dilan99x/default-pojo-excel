package com.dbs.plugin.constants;

public class ExcelHeaderConstants {

    public static final String SHEET_NAME = "SG Mapping";

    // Common headers
    public static final String GLOBAL_API_FIELDNAME = "Global API Fieldname";
    public static final String GLOBAL_API_DATATYPE = "Global API DataType"; // ✅ Fix: single space

    // Sun CBS section
    public static final String SUNCBS_FIELDNAME = "Sun CBS Fieldname";
    public static final String SUNCBS_DATATYPE = "Sun CBS DataType";
    public static final String SUNCBS_OPERATION = "Sun CBS Custom Operation";
    public static final String SUNCBS_TRANSFORM_VALUE = "Sun CBS Transform Value";

    // Mainframe section
    public static final String MAINFRAME_FIELDNAME = "Mainframe Fieldname";
    public static final String MAINFRAME_DATATYPE = "Mainframe DataType";
    public static final String MAINFRAME_OPERATION = "Mainframe Custom Operation";
    public static final String MAINFRAME_TRANSFORM_VALUE = "Mainframe Transform Value";

    // Section markers
    public static final String REQUEST_MARKER = "Request";
    public static final String RESPONSE_MARKER = "Response";

    // New validation columns
    public static final String APPLICABLE_COUNTRY = "Applicable Country";
    public static final String SG_MANDATORY = "SG Mandatory";
}
