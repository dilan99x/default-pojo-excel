package com.dbs.plugin.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonInclude;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiField {
    private String source;
    private String sourceDataType;
    private String target;
    private String targetDataType;
    private String operationType;
    private String customData;
}
